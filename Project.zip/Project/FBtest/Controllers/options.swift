//
//  options.swift
//  FBtest
//
//  Created by Sreejith Thrivikraman on 2018-07-30.
//  Copyright © 2018 robin. All rights reserved.
//

import Foundation

class options : NSDictionary
{
    var key : String?
    var value: String?
}
